package edu.ncsu.csc216.product_backlog.model.io;

import java.util.ArrayList;

import edu.ncsu.csc216.product_backlog.model.product.Product;
import edu.ncsu.csc216.product_backlog.model.task.Task;
/**
 * Reads in the products from a file. 
 * @author Jay Lakhani
 *
 */
public class ProductsReader {
	/**
	 * Constructs Product Reader
	 */
	public ProductsReader() {
		// TODO Auto-generated method stub

	}
	/**
	 * Reads products from a file and generates a list of valid products.  If the file to read cannot be found or the
	 * permissions are incorrect a File NotFoundException is thrown.
	 * 
	 * @param fileName file to read product from
	 * @return a list of valid products
	 * @throws FileNotFoundException if the file cannot be found or read
	 */
	public static ArrayList<Product> readProductsFile(String fileName){
		
		return null;	
	}
	/**
	 * Checks if any products are invalid 
	 * @param product the product
	 * @return returns the valid product
	 */
	private static Product processProduct(String product) {
		return null;	
	}
	/**
	 * Checks if any tasks are invalid 
	 * @param task the task
	 * @return returns the valid task
	 */
	private static Task processTask(String task) {
		return null;
	}
}
