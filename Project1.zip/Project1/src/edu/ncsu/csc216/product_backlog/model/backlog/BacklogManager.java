package edu.ncsu.csc216.product_backlog.model.backlog;

import edu.ncsu.csc216.product_backlog.model.command.Command;
import edu.ncsu.csc216.product_backlog.model.task.Task;
import edu.ncsu.csc216.product_backlog.model.task.Task.Type;

/**
 * Backlog Manager saves and loads tasks from a file as an array. Also,
 * it can add and delete tasks and products from the array list. Additionally, this class
 * can edit, delete, and clear products.
 * @author Jay Lakhani
 *
 */
public class BacklogManager {
	
	/**singleton instance*/
	private static BacklogManager singleton;
	/** Backlog manager instance */
	private BacklogManager BacklogManager;

	/**
	  * Constructs Backlog Manager
	  */
	private BacklogManager() {
		BacklogManager = new BacklogManager();
	}
	
	/**
	 * Returns the instance of BacklogManager
	 * @return returns the instance of Backlog manager
	 */
	public static BacklogManager getInstance() {
		if (singleton == null) {
			singleton = new BacklogManager();
		}
		return singleton;
	}
	
	/**
	 * Writes the file to the Product writer class 
	 * @param fileName the name of the file
	 * throws an IllegalArgumentException if there are no tasks 
	 * or if the current project is null
	 */
	public void saveToFile(String fileName) {
		
	}
	
	/**
	 * Reads the product list in the file
	 * @param fileName the name of the file
	 */
	public void loadFromFile(String fileName) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Finds the product in the list
	 * @param productName the name of the product
	 * throws an IllegalArgumentException if the product is no in the list
	 */
	public void loadProduct(String productName) {
		if(this.getProductName() != productName) { 
			throw new IllegalArgumentException("Product not available");
		}
	}
	/**
	 * Checks the list of products to see if any are duplicates
	 * @param productName the name of the product
	 */
	private void isDuplicateProduct(String productName) {
		// TODO Auto-generated method stub
	}
	/**
	 * Gets the tasks as a 2D array
	 * @return returns the 2D array of tasks
	 */
	public String[][] getTasksAsArray() {
		return null;
		
	}
	/**
	 * Searches the task list for the task with a specific id
	 * @param taskId the id assigned to a task
	 * @return returns the task with the assigned id
	 */
	public Task getTaskById(int taskId) {
		
		return null;
	}
	/**
	 * Finds the task with the id that is passed in and then updates it with the command given.
	 * @param id the id of the task
	 * @param c the command that is passed in
	 */
	public void executeCommand(int id, Command c) {
		// TODO Auto-generated method stub
	}
	/**
	 * Deletes the task with the assigned id
	 * @param id the id assigned to a task
	 */
	public void deleteTaskById(int id) {
		// TODO Auto-generated method stub
	}
	/**
	 * Adds a task to the list in the product
	 * @param productName the name of the product 
	 * @param type the type of task
	 * @param creator the creator of the task
	 * @param note any notes with the task
	 */
	public void addTaskToProduct(String productName, Type type, String creator, String note) {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Gets the product name
	 * @return returns the product name
	 */
	public String getProductName() {
		
		return;
	}
	/**
	 * Gets the list of products
	 * @return returns the list of products
	 */
	public String[] getProductList() {
		// TODO Auto-generated method stub
		return null;
	}
	/**
	 * Clears all the products. Causes the current product to be null
	 */
	public void clearProducts() {
		// TODO Auto-generated method stub
		
	}
	/**
	 * Edits the selected product's name
	 * @param updateName the updated name of the product
	 * throws an IllegalArgumentException if no product is selected
	 */
	public void editProduct(String updateName) {
		if (updateName == null) {
			throw new IllegalArgumentException("No product selected");
		}
	}
	
	/**
	 * 
	 * Adds a product to the 2D array of products
	 * @param productName the name of the product
	 * throws an IllegalArgumentException if the product is null or an empty string
	 */
	public void addProduct(String productName) {
		
		if(productName == null || this.getProductName() == productName) {
			throw new IllegalArgumentException("Invalid Product Name");
		}
		
	}
	/**
	 * Deletes the product from the 2D array
	 * throws an IllegalArgumentException if the current product is null
	 */
	public void deleteProduct() {
		if(this.getProductName() == null) {
			throw new IllegalArgumentException("No Product Selected");
		}		
	}
	/**
	 * Resets the backlog manager. Intended for testing the class
	 */
	protected void resetManager() {
		// TODO Auto-generated method stub
	}
}
