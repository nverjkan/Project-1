package edu.ncsu.csc216.product_backlog.model.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.List;

import edu.ncsu.csc216.product_backlog.model.product.Product;
/**
 * Writes the list of products to a file.
 * @author Jay Lakhani
 *
 */
public class ProductsWriter {
	
	/**
	 * Constructs ProductsWriter
	 */
	public ProductsWriter() {
		// TODO Auto-generated method stub

	}
	/**
	 * Writes the list of products to a file
	 * @param fileName the name of the file with the product
	 * @param products the list of products in a file
	 * throws an IllegalArgumentException if there are any errors or exceptions
	 * @throws FileNotFoundException 
	 */
	public static void writeProductsToFile(String fileName, List<Product> products) throws FileNotFoundException {
		PrintStream fileWriter = new PrintStream(new File(fileName));

		for (int i = 0; i < products.size(); i++) {
			fileWriter.println(products.get(i).toString());
		}

		fileWriter.close();
	}
}
