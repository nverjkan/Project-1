package edu.ncsu.csc216.product_backlog.model.product;


import java.util.List;

import edu.ncsu.csc216.product_backlog.model.command.Command;
import edu.ncsu.csc216.product_backlog.model.task.Task;
import edu.ncsu.csc216.product_backlog.model.task.Task.Type;
/**
 * The product class. This class can set the product name. Additionally, it 
 * can add tasks and delete tasks with a specified id.
 * @author Jay Lakhani
 *
 */
public class Product {
	/** The name of the product*/
	private String productName = "";
	/** The counter sets the task ids for the product*/
	private int counter = 1;
	/**
	 * The constructor for Product
	 * @param productName the name of the product
	 * */
	public Product(String productName) {
		Product p = new Product(productName);
	}
	/**
	 * Sets the product name
	 * @param productName the name of the product
	 * throws an IllegalArgumentException if the product is null or empty
	 */
	public void setProductName(String productName) {
		if (productName.equals("") || productName == null) {
			throw new IllegalArgumentException("Invalid productName");
		}
		this.productName = productName;
	}
	/**
	 * Gets the product name
	 * @return returns the product name
	 */
	public String getProductName() {
		return productName;
		
	}
	/**
	 * Finds the largest task id in the task. If the task is empty the task counter is set to one
	 */
	private void setTaskCounter() {
		for (int i = 0; i < )

	}
	/**
	 * Empties the list of tasks
	 */
	private void emptyList() {
		Product p = new Product(productName);

	}
	/**
	 * Add a task to the product
	 * @param task the task given to a product
	 * throws an IllegalArgumentException if the task already exists
	 */
	public void addTask(Task task) {
		Product p = new Product(productName);
		p.addTask(task);
	}
	/**
	 * Creates a new task with the given information
	 * @param title the title of the task
	 * @param type the type of task
	 * @param creator the creator of the task
	 * @param note the note associated with the task
	 */
	public void addTask(String title, Type type, String creator, String note) {
		Task t = new Task(title, type, creator, note);
	}
	/**
	 * Gets the task
	 * @return returns the task
	 */
	public List<Task> getTasks() {
		return null;
	}
	/**
	 * Gets the task with the given id
	 * @param id the id of the task
	 * @return returns the task with the given id
	 */
	public Task getTaskById(int id) {
		return null;
	}
	/**
	 * Finds the task with the given id
	 * @param id the given id for a task
	 * @param c the command given to a task
	 */
	public void executeCommand(int id, Command c) {
		
	}
	/**
	 * Deletes a task with a given id
	 * @param id the given id with a task
	 */
	public void deleteTaskById(int id) {
		
	}
}
