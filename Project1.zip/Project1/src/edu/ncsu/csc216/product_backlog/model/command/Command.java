package edu.ncsu.csc216.product_backlog.model.command;
/**
 * Takes in the user inputs so that the state of the tasks can be updated 
 * @author Jay Lakhani 
 *
 */
public class Command {
	/**
	 * The task states that the user can set the task to.
	 * @author Jay Lakhani
	 *
	 */
	public enum CommandValue { 
		/** Backlog command value*/
		BACKLOG, 
		/** Claim command value*/
		CLAIM, 
		/** Process command value*/
		PROCESS, 
		/** Verify command value*/
		VERIFY, 
		/** Complete command value*/
		COMPLETE,
		/** Reject command value*/
		REJECT;
	}
	/** A note added with the command*/
	private String note = "";
	/** The owner of the command*/
	private String owner = "";
	
	/** command value*/
	private CommandValue c;
	
	
	
	/** An error message if the command cannot be done*/
	private static final String COMMAND_ERROR_MESSAGE = "Invalid command"; 
	
	
	/**
	 * Constructs the command class
	 * @param c The type of command. (i.e. Backlog, Claim, Process, etc)
	 * @param owner the owner of the command
	 * @param noteText the note associated with the command
	 */
	public Command (CommandValue c, String owner, String noteText) {
		
		this.c = c;
		this.owner = owner;
		this.note = noteText;
		
		if (c == null || noteText.isEmpty() || owner.isEmpty()) {
			throw new IllegalArgumentException();
		}
	
		
	}
	/**
	 * Gets the command value.
	 * @return returns the type of command. (i.e. Backlog, Claim, Process, etc)
	 */
	public CommandValue getCommand() {
		return c;
	}
	/**
	 * Gets the note at text
	 * @return returns the note as a string
	 */
	public String getNoteText() {
		return this.note;
	}
	/**
	 * Gets the owner of the command
	 * @return return the owner as a string
	 */
	public String getOwner() {
		return owner;
	}
}
