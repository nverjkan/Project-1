package edu.ncsu.csc216.product_backlog.model.task;

import java.util.ArrayList;

import edu.ncsu.csc216.product_backlog.model.command.Command;
/**
 * 
 * The task class. This class can set the task type, state, creator, owner, title, notes, and id. 
 * Additionally, it checks if the the task is valid.  
 * @author Jay Lakhani
 *
 */
public class Task {
	/** The id associated with a task*/
	private int taskId = 0;
	/** The title of a task*/
	private String title = "";
	/** The creator of a task*/
	private String creator = "";
	/** The owner of a task*/
	private String owner = "";
	/** Checks if a task is verified*/
	private boolean isVerified;
	/** Notes associated with a task*/
	private ArrayList<String> notes;
	/** Backlog state of a task*/
	public static final String BACKLOG_NAME = "Backlog";
	/** Owned state of a task*/
	public static final String OWNED_NAME = "Owned";
	/** Processing state of a task*/
	public static final String PROCESSING_NAME = "Processing";
	/** Verifying state of a task*/
	public static final String VERIFYING_NAME = "Verifying";
	/** Done state of a task*/
	public static final String DONE_NAME = "Done";
	/** Rejected state of a task*/
	public static final String REJECTED_NAME = "Rejected";
	/** Feature state of a task*/
	public static final String FEATURE_NAME  = "Feature";
	/** Bug state of a task*/
	public static final String BUG_NAME = "Bug";
	/** Technical Work type of a task*/
	public static final String TECHNICAL_WORK_NAME  = "Technical Work";
	/** Knowledge Acquisition type of a task*/
	public static final String KNOWLEDGE_ACQUISITION_NAME  = "Knowledge Acquisition";
	/** Feature type of a task*/
	public static final String T_FEATURE  = "F";
	/** Bug type of a task*/
	public static final String T_BUG  = "B";
	/** Technical Work type of a task*/
	public static final String T_TECHNICAL_WORK = "TW";
	/** Knowledge Acquisition type of a task*/
	public static final String T_KNOWLEDGE_ACQUISITION = "KW";
	/** Unowned type of a task*/
	public static final String UNOWNED = "unowned";

	/**
	 * An enumerated list of task types
	 * @author Jay Lakhani
	 *
	 */
	public enum Type { FEATURE, BUG, TECHNICAL_WORK, KNOWLEDGE_ACQUISITION }
	/**
	 * Constructs the task class
	 * @param id the task id
	 * @param title the title of the task
	 * @param type the type of task
	 * @param creator the creator of a task
	 * @param note the note associated with a task
	 */
	public Task(int id, String title, Type type, String creator, String note) {
		if (title == null || ("").equals(title) || null == type || null == creator || ("").equals(creator) || null == note 
				|| ("").equals(note) || id <= 0) {
			throw new IllegalArgumentException("Invalid task information");
		}
		
		this.taskId = id;
		this.title = title;
		this.creator = creator;
		setType(Type.FEATURE);
		setOwner(UNOWNED);
		addNoteToList(note);
		
	}
	/**
	 * Constructs the task class
	 * @param id the id of the task
	 * @param state the state of a task
	 * @param title the title of a task
	 * @param type the type of task
	 * @param creator the creator of the task
	 * @param owner the owner of the task
	 * @param verified Whether the task is verified 
	 * @param notes the notes associated with a task
	 */
	public Task(int id, String state, String title, String type, String creator, String owner, String verified, ArrayList<String> notes ) {
		
		setTaskId(id);
		setState(state);
		setTitle(title);
		setCreator(creator);
		if(state.equals(BACKLOG_NAME)) {
		setOwner(UNOWNED);
		}
		setOwner(owner);
		this.isVerified = Boolean.valueOf(isVerified);
		setNotes(notes);
		
	}

	
	/**
	 * Sets the task id
	 * @param taskId the value given the a task
	 */
	private void setTaskId(int taskId) {
		
		this.taskId = taskId;
	}
	/**
	 * Sets the task title
	 * @param title the title of a task
	 */
	private void setTitle(String title) {
		
		this.title = title;
	}
	/**
	 * Sets the type of task
	 * @param type the type of task
	 */
	private void setType(Type type) {
		if (type.toString().equals(T_FEATURE)) {
			
		} 
		
		
	}
	
	/**
	 * Sets the creator of the task
	 * @param creator the creator of the task
	 */
	private void setCreator(String creator) {
		this.creator = creator;
	}
	
	/**
	 * Sets the owner of the task
	 * @param owner the owner of the task
	 */
	private void setOwner(String owner) {
		this.owner = owner;
	}
	

	/**
	 * Checks if the task is verified
	 * @param isVerified true means that the task is verified. false means that the task is not verified
	 */
	private void setVerified(boolean isVerified) {
		
		this.isVerified = isVerified;
	}
	/**
	 * Sets notes as an array list for tasks
	 * @param notes an array list of notes
	 */
	private void setNotes(ArrayList<String> notes) {
		this.notes = notes;
	}
	/**
	 * Adds a note to a list
	 * @param notes A string that is passed in with the note
	 * @return returns the id associated with the note
	 */
	public int addNoteToList(String notes) {
		
		return 0;
		
	}
	
	/**
	 * Gets the task id
	 * @return the taskId is the associated id of a task
	 */
	public int getTaskId() {
		return taskId;
	}
	/**
	 * Gets the state name
	 * @return returns the states name
	 */
	public String getStateName() {
		return null;
	}
	/**
	 * Sets the state of the task
	 * @param state the state of the task
	 */
	private void setState(String state) {
		

	}
	/**
	 * Sets the type of task from a string
	 * @param type the type of task
	 */
	private void setTypeFromString(String type) {
		// TODO Auto-generated method stub

	}
	/**
	 * Gets the type of task
	 * @return returns the type of task
	 */
	public Type getType() {
		return null;
	}
	/**
	 * Gets the short name of a task
	 * @return returns the short name of a task (i.e. F,B,TW, and KA)
	 */
	public String getTypeShortName() {
		return null;
		
	}
	/**
	 * Gets the type of task as a long name
	 * @return returns the long name(i.e. Bug, Feature, etc...)
	 */
	public String getTypeLongName() {
		return null;
		
	}
	
	/**
	 * Gets the owner of the task
	 * @return returns the owner of the task
	 */
	public String getOwner() {
		return owner;
	}
	
	/**
	 * Gets the title of the task
	 * @return the title of the task
	 */
	public String getTitle() {
		return title;
	}
	
	/**
	 * Gets the creator of the task
	 * @return returns the creator of the task
	 */
	public String getCreator() {
		return creator;
	}
	
	/**
	 * Checks if the task is verified
	 * @return returns true if the task is verified. Otherwise, returns false
	 */
	public boolean isVerified() {
		return isVerified;
	}
	/**
	 * Get an array list of notes
	 * @return returns an array list of notes
	 */
	public ArrayList<String> getNotes() {
		
		return null;
		
	}
	/**
	 * Gets the notes list as a string
	 * @return returns a string of notes
	 */
	public String getNotesList() {
		return null;
	}
	/**
	 * Creates a proper output for task so that it matches valid files
	 * @return returns a string of the proper format for a task
	 */
	public String toString() {
		return null;
	}
	/**
	 * Updates the state of the task
	 * @param command the command given to a task
	 * throws an UnsupportedOperationException
	 */
	public void update(Command command) {
		// TODO Auto-generated method stub
	}
	/**
	 * Gets an array of notes
	 * @return returns an array of notes
	 */
	public String[] getNotesArray() {
		return null;
	}

	

	/**
	 * Interface for states in the Task State Pattern.  All 
	 * concrete task states must implement the TaskState interface.
	 * 
	 * @author Dr. Sarah Heckman (sarah_heckman@ncsu.edu) 
	 */
	private interface TaskState {
		
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param c Command describing the action that will update the Task
		 * state.
		 * @throws UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		void updateState(Command c);
		
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		String getStateName();
	
	}
	/**
	 * A concrete inner class for task. Updates the task to the Backlog state
	 * @author Jay Lakhani
	 *
	 */
	public class BacklogState {
		private BacklogState() {
			
		}
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param command describing the action that will update the Task
		 * state.
		 * UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		public void updateState(Command command) {
			// TODO Auto-generated method stub

		}
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		public String getStateName() {
			return BACKLOG_NAME;
		}
	}
	/**
	 * A concrete inner class for task. Updates the task to the OwnedState
	 * @author Jay Lakhani
	 *
	 */
	public class OwnedState {
		private OwnedState() {
			
		}
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param command describing the action that will update the Task
		 * state.
		 * UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		public void updateState(Command command) {
		
		}
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		public String getStateName() {
			return null;
		}
	}
	/**
	 * A concrete inner class for task. Updates the task to the VerifyingState
	 * @author Jay Lakhani
	 *
	 */
	public class VerifyingState {
		private VerifyingState() {
			
		}
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param command describing the action that will update the Task
		 * state.
		 * UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		public void updateState(Command command) {
			// TODO Auto-generated method stub

		}
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		public String getStateName() {
			return null;
		}
	}
	/**
	 * A concrete inner class for task. Updates the task to the ProcessingState
	 * @author Jay Lakhani
	 *
	 */
	public class ProcessingState {
		private ProcessingState() {
			
		}
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param command describing the action that will update the Task
		 * state.
		 * UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		public void updateState(Command command) {
			// TODO Auto-generated method stub

		}
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		public String getStateName() {
			return null;
		}
	}
	/**
	 * A concrete inner class for task. Updates the task to the DoneState
	 * @author Jay Lakhani
	 *
	 */
	public class DoneState {
		private DoneState() {
			
		}
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param command describing the action that will update the Task
		 * state.
		 * UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		public void updateState(Command command) {
			// TODO Auto-generated method stub

		}
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		public String getStateName() {
			return null;
		}
	}
	/**
	 * A concrete inner class for task. Updates the task to the DoneState
	 * @author Jay Lakhani
	 *
	 */
	public class RejectedState {
		private RejectedState() {
			
		}
		/**
		 * Update the Task based on the given Command
		 * An UnsupportedOperationException is thrown if the Command is not a
		 * is not a valid action for the given state.  
		 * @param command describing the action that will update the Task
		 * state.
		 * UnsupportedOperationException if the Command is not a valid action
		 * for the given state.
		 */
		public void updateState(Command command) {
			// TODO Auto-generated method stub

		}
		/**
		 * Returns the name of the current state as a String.
		 * @return the name of the current state as a String.
		 */
		public String getStateName() {
			return null;
		}
	}

}
