Product Backlog Testing Files

tasks0.txt - File doesn't exist. 
tasks1.txt - Valid file with two products
tasks2.txt - Valid file with one product where the task ids are out of order and there's a duplicate task id
tasks3.txt - missing product name
tasks4.txt - missing id 
tasks5.txt - incorrect state
tasks6.txt - missing state
tasks7.txt - missing title
tasks8.txt - incorrect type
tasks9.txt - missing type
tasks10.txt - missing creator
tasks11.txt - missing owner
tasks12.txt - missing is verified
tasks13.txt - missing log
tasks14.txt - Product without a task
tasks15.txt - Negative id
tasks16.txt - Backlog state with incorrect owner
tasks17.txt - Owned state with incorrect owner
tasks18.txt - Processing state with incorrect owner
tasks19.txt - Verifying state with incorrect owner
tasks20.txt - Done state with incorrect owner
tasks21.txt - Rejected state with incorrect owner
tasks22.txt - Bug in Done state without verification
tasks23.txt - Feature in Done state without verification
tasks24.txt - Technical Work in Done state without verification
tasks25.txt - Knowledge Acquisition in Done state that is verified
