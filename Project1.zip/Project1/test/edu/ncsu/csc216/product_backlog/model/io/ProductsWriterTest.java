package edu.ncsu.csc216.product_backlog.model.io;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProductsWriterTest {

	@Test
	void testProductsWriter() {
		fail("Not yet implemented");
	}

	@Test
	void testWriteProductsToFile() {
		fail("Not yet implemented");
	}

}
