package edu.ncsu.csc216.product_backlog.model.product;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ProductTest {

	@Test
	void testProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testSetProductName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetProductName() {
		fail("Not yet implemented");
	}

	@Test
	void testAddTask() {
		fail("Not yet implemented");
	}

	@Test
	void testAddTasks() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTasks() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTasksById() {
		fail("Not yet implemented");
	}

	@Test
	void testExecuteCommand() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteTaskById() {
		fail("Not yet implemented");
	}

}
