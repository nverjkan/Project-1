package edu.ncsu.csc216.product_backlog.model.command;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.product_backlog.model.command.Command.CommandValue;

class CommandTest {

	@Test
	public void testCommand() {
		try {
		Command c = new Command(null, "owner1", "note1" );
		fail();
		} catch(IllegalArgumentException e) {
			//skip
		}
		
		try {
			Command c1 = new Command(CommandValue.COMPLETE, "", "note1" );
			fail();
		} catch(IllegalArgumentException e) {
			//skip
		}
		
		try {
			Command c2 = new Command(CommandValue.COMPLETE, "owner1", "" );
			fail();
		} catch(IllegalArgumentException e) {
			//skip
		}

	}

	@Test
	public void testGetCommand() {
		Command c3 = new Command(CommandValue.COMPLETE, "owner1", "note1" );
		
		assertEquals(c3.getCommand(), CommandValue.COMPLETE);
	}

	@Test
	public void testGetNoteText() {
		Command c4 = new Command(CommandValue.COMPLETE, "owner1", "note1" );
		
		assertEquals(c4.getNoteText(), "note1");
	}

	@Test
	public void testGetOwner() {
		Command c5 = new Command(CommandValue.COMPLETE, "owner1", "note1" );
		
		assertEquals(c5.getOwner(), "owner1");
	}

}
