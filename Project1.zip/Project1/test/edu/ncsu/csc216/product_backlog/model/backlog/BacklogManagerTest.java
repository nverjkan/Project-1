package edu.ncsu.csc216.product_backlog.model.backlog;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class BacklogManagerTest {

	@Test
	void testGetInstance() {
		fail("Not yet implemented");
	}

	@Test
	void testSaveToFile() {
		fail("Not yet implemented");
	}

	@Test
	void testLoadFromFile() {
		fail("Not yet implemented");
	}

	@Test
	void testLoadProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTasksAsArray() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTaskById() {
		fail("Not yet implemented");
	}

	@Test
	void testExecuteCommand() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteTaskById() {
		fail("Not yet implemented");
	}

	@Test
	void testAddTaskToProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testGetProductName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetProductList() {
		fail("Not yet implemented");
	}

	@Test
	void testClearProducts() {
		fail("Not yet implemented");
	}

	@Test
	void testEditProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testAddProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testResetManager() {
		fail("Not yet implemented");
	}

}
