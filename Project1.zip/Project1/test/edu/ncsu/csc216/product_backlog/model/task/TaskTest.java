package edu.ncsu.csc216.product_backlog.model.task;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import edu.ncsu.csc216.product_backlog.model.task.Task.Type;

class TaskTest {


	@Test
	void testTaskIntStringTypeStringString() {
		fail("Not yet implemented");
	}

	@Test
	void testTaskIntStringStringStringStringStringArrayListOfString() {
		fail("Not yet implemented");
	}

	@Test
	void testAddNoteToList() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTaskId() {
		fail("Not yet implemented");
	}

	@Test
	void testGetStateName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetType() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTypeShortName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTypeLongName() {
		fail("Not yet implemented");
	}

	@Test
	void testGetOwner() {
		fail("Not yet implemented");
	}

	@Test
	void testGetTitle() {
		fail("Not yet implemented");
	}

	@Test
	void testGetCreator() {
		fail("Not yet implemented");
	}

	@Test
	void testIsVerified() {
		fail("Not yet implemented");
	}

	@Test
	void testGetNotes() {
		fail("Not yet implemented");
	}

	@Test
	void testGetNotesList() {
		fail("Not yet implemented");
	}

	@Test
	void testToString() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	void testGetNotesArray() {
		fail("Not yet implemented");
	}

}
